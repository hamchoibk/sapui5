/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package MarkManagement;

/**
 *
 * @author Administrator
 */
public class Mark 
{
    public Mark(){}
    
    public Mark(String id, String value)
    {
        this.value = value;
        this.ID = id;
    }
    
    public String value;
    public String ID;
}
