/**
 * 
 * by Nguyen Van Ha
 */
$("‪#‎Signin‬--authenticationUserId-inner").val("dev006");
$("#Signin--authenticationPin-inner").val("P@ssword1");
$('‪#‎__button0‬').trigger('tap');
$("#Signin--authenticationUserId-inner").val("vanvh90");
$("#Signin--authenticationPin-inner").val("P@ssword10");
$('#__button0').trigger('tap');
$("‪#‎PayBill‬--fiid").show();
var text = v.ihidde.getValue;
console.log(evt.getId);
console.log(evt.getSource());
console.log(evt.getParameters());
console.log(evt.getParameters().selected);
console.log(evt.getParameters().text);
console.log(evt.oSource.mProperties.text);
console.log(evt.oSource.mProperties);