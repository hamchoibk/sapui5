package home.com;

public class Main {
	public static void main(String args[])
	{
		// Oke roi nhe
		System.out.println(" Hello World ");
		for(int i = 0; i < 100; i++)
		{
			System.out.println(" Hello World ");
		}
	}

}
